﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathMenu : MonoBehaviour
{
    
    void Start()
    {
        gameObject.SetActive(false);//bawt dau chay => an
    }

    public void ToggleEndMenu(float score)
    {
        gameObject.SetActive(true);
    }
    void Update()
    {
        
    }
}
