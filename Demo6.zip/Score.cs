﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    //khai bao bien
    private float scoreHigh = 0.0f;
    public Text scoreText;//cap nhat text
    private int difficultLevel = 1;
    private int maxDifficultLevel = 10;
    private int scoreToNextLevel = 10;
    
    
    void Start()
    {
        
    }
    //ham tang level
    void LevelUp()
    {
        if (difficultLevel == maxDifficultLevel)
            return;
        scoreToNextLevel *= 2;//diem chuyen level tang gap 2
        difficultLevel++;//do kho tang len 1
        GetComponent<PlayerMotor>().SetSpeed(difficultLevel);//truy cap ham setSpeed cua PlayerMotor
        Debug.Log(difficultLevel);
    }

    void Update()
    {
        if (isDead)//khi nhan vat chet => khong tang diem
            return;
        if (scoreHigh >= scoreToNextLevel)
            LevelUp();
        scoreHigh += Time.deltaTime * difficultLevel;//thay doi diem theo thoi gian
        scoreText.text = ((int)scoreHigh).ToString();
    }

    public DeathMenu deathMenu;
    private bool isDead = false;
    public void OnDeath()
    {
        isDead = true;
        deathMenu.ToggleEndMenu(scoreHigh); //hien thi menu
       
    }
}
