﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TilesManager : MonoBehaviour
{
    public GameObject[] tilePrefabs;//prefabs
    private Transform p;//nhan vat
    private float spawnz = 0.0f;
    private float tileLength = 10.0f;//chieu dai doan duong
    private int tilesOnScreen = 3;//so luong doan duong hien thi tren man hinh
    private float safeZone = 15.0f;
    private List<GameObject> activeTiles;//dia hinh activie
    private int lastPrefabIndex = 0;//chi so
    void Start()
    {
        activeTiles = new List<GameObject>();
        p = GameObject.FindGameObjectWithTag("Player").transform;//anh xa
        for (int i = 0; i < tilesOnScreen; i++)
        {
            if (i < 2)
                SpawnzTile(0);//hoan vi
            else
                SpawnzTile();
        }
    }
    //dinh nghia ham hoan vi
    private void SpawnzTile(int prefabIndex = -1)
    {
        GameObject gao;
        if (prefabIndex == -1)
            gao = Instantiate(tilePrefabs[RandomPrefabIndex()]) as GameObject;
        else
            gao = Instantiate(tilePrefabs[prefabIndex]) as GameObject;
        gao.transform.SetParent(transform);
        gao.transform.position = Vector3.forward * spawnz;
        spawnz += tileLength;
        activeTiles.Add(gao);
    }
    //dinh nghia ham random
    private int RandomPrefabIndex()
    {
        if (tilePrefabs.Length <= 1)
        {
            return 0;
        }
        int randomIndex = lastPrefabIndex;
        while (randomIndex == lastPrefabIndex)
        {
            randomIndex = Random.Range(0, tilePrefabs.Length);
        }
        lastPrefabIndex = randomIndex;
        return randomIndex;
    }
    //ham xoa dia hinh
    private void deleteTile()
    {
        Destroy(activeTiles[0]);
        activeTiles.RemoveAt(0);
    }
    
    void Update()
    {
        if (p.position.z - safeZone > (spawnz - tilesOnScreen * tileLength))
        {
            SpawnzTile();
            deleteTile();
        }
    }
}
