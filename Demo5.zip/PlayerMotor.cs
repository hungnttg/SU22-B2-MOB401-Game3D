﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    Vector3 move;
    private float speed = 5.0f;//toc do
    private CharacterController controller;
    private float verticalVelocity = 0.0f;
    private float gravity = 10.0f;
    private float animationDuration = 3.0f;
    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    private bool isDead = false;
    private void Death()
    {
        isDead = true;
        GetComponent<Score>().OnDeath();
//        Debug.Log("Nhan vat chet");
    }
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.point.z > transform.position.z + controller.radius)
            Death();
    }
    void Update()
    {
        if (isDead)
            return;
        if (Time.time < animationDuration)
        {
            controller.Move(Vector3.forward * speed * Time.deltaTime);
            return;
        }
        move = Vector3.zero;
        if (controller.isGrounded)
        {
            verticalVelocity = -0.5f;
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }
        //X:(trai, phai)
        move.x = Input.GetAxisRaw("Horizontal") * speed;
        //Y: len, xuong
        move.y = verticalVelocity;
        //Z: tien, lui
        move.z = speed;
        controller.Move(move * Time.deltaTime);
    }
    
    
    public void SetSpeed(float m)
    {
        speed = 5.0f + m;
    }
}
