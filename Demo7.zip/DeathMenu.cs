﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DeathMenu : MonoBehaviour
{
    private float transition = 0.0f;
    public Text scoreText;//diem
    public Image backgroundImage;//background
    private bool isShowed = false;//trang thai hien thi

    
    void Start()
    {
        gameObject.SetActive(false);//bawt dau chay => an
    }

    public void ToggleEndMenu(float score)
    {
        gameObject.SetActive(true);
        scoreText.text = ((int)score).ToString();//hien thi diem cuoi cung
        isShowed = true;//thiet lap trang thai hien thi
    }
    public void Restart()
    {
        SceneManager.LoadScene("SampleScene");
        //SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void Update()
    {
        if (!isShowed)
            return;

        transition += Time.deltaTime;//chuyen doi theo thoi gian
        backgroundImage.color =
            Color.Lerp(new Color(0,0,0,0),Color.black, transition);//thay doi mau
    }
}
